package com.ledemotions.ledep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LedepApplicationTests {

	@Test
	void contextLoads() {
	}

}
