package com.ledemotions.ledep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LedepApplication {

	public static void main(String[] args) {
		SpringApplication.run(LedepApplication.class, args);
	}

}
